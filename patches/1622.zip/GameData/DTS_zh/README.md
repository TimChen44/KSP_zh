#介绍

这里放置各类汉化程序需要的资源文件，汉化工作只要对这些文件的补充即可。
文件均为utf-8编码格式的xml文件。

###Image

贴图资源

###cnfont

字库

###xSquad

资源汉化

功能同zhConfig.xml，这里支持创建多个文件便于整理

###en.xml

原始文本--禁止修改

###zh.xml

汉化后文本

###en_x64.xml

原始文本(64位)--禁止修改

###zh_x64.xml

汉化后文本(64位)

###zhConfig.xml

资源汉化

###zhImage.xml

贴图资源配置

###zhLoadingTips.xml

启动吐槽文件
